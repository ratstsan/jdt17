-- G2: Julius, Rifqi, Naufal
-- CRUD examples on the bottom!

-- 1. Create Tables
CREATE TABLE users (
    id VARCHAR(20) PRIMARY KEY,
    full_name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL CHECK (role IN ('ADMIN', 'USER')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE events (
    id VARCHAR(20) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    event_date TIMESTAMP WITH TIME ZONE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE ticket_types (
    id VARCHAR(20) PRIMARY KEY,
    event_id VARCHAR(20) NOT NULL REFERENCES events(id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    price NUMERIC(12, 2) NOT NULL,
    stock INTEGER NOT NULL CHECK (stock >= 0),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE transactions (
    id VARCHAR(30) PRIMARY KEY,
    user_id VARCHAR(20) NOT NULL REFERENCES users(id),
    ticket_type_id VARCHAR(20) NOT NULL REFERENCES ticket_types(id),
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    total_amount NUMERIC(12, 2) NOT NULL,
    
    -- Status Definitions:
    -- PENDING: User won the queue. Ticket is temporarily reserved (stock deducted) pending payment.
    -- PAID: Bank verified payment. Transaction complete, ticket permanently secured.
    -- FAILED: Payment actively rejected (e.g., insufficient funds). Ticket is returned to stock.
    -- EXPIRED: Payment time limit ran out. Ticket is returned to stock.
    status VARCHAR(50) NOT NULL CHECK (status IN ('PENDING', 'PAID', 'FAILED', 'EXPIRED')),
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Store the description in the database schema metadata
COMMENT ON COLUMN transactions.status IS 'PENDING: Reserved awaiting payment. PAID: Payment verified. FAILED: Payment rejected. EXPIRED: Time limit exceeded.';

CREATE TABLE payments (
    id VARCHAR(30) PRIMARY KEY,
    transaction_id VARCHAR(30) NOT NULL UNIQUE REFERENCES transactions(id) ON DELETE CASCADE,
    bank_name VARCHAR(100) NOT NULL,
    virtual_account_number VARCHAR(50) NOT NULL,
    expired_at TIMESTAMP WITH TIME ZONE NOT NULL,
    paid_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 2. Indexes for Performance
CREATE INDEX idx_transactions_user_id ON transactions(user_id);
CREATE INDEX idx_transactions_status ON transactions(status);
CREATE INDEX idx_payments_va_number ON payments(virtual_account_number);

-- 3. Insert Dummy Data
INSERT INTO users (id, full_name, email, password_hash, role) VALUES 
('AM', 'Ahmad Muhammad', 'ahmad@example.com', 'hash123', 'USER'),
('JD', 'Jane Doe', 'jane@example.com', 'hash456', 'USER'),
('SA', 'System Admin', 'admin@ticketwar.com', 'hash789', 'ADMIN');

INSERT INTO events (id, name, event_date) VALUES 
('MOTS', 'Coldplay: Music of the Spheres', '2026-11-15 19:00:00+07'),
('ERAS', 'Taylor Swift: The Eras Tour', '2026-12-01 19:00:00+07');

INSERT INTO ticket_types (id, event_id, name, price, stock) VALUES 
('MOTS-VIP', 'MOTS', 'Ultimate Spheres Experience', 11000000.00, 500),
('MOTS-FES', 'MOTS', 'Festival Free Standing', 3500000.00, 5000),
('ERAS-CAT1', 'ERAS', 'Category 1 Seating', 5000000.00, 2000);

INSERT INTO transactions (id, user_id, ticket_type_id, quantity, total_amount, status) VALUES 
('TRX-AM-01', 'AM', 'MOTS-VIP', 2, 22000000.00, 'PAID'),
('TRX-JD-01', 'JD', 'ERAS-CAT1', 1, 5000000.00, 'PENDING');

INSERT INTO payments (id, transaction_id, bank_name, virtual_account_number, expired_at, paid_at) VALUES 
('PAY-AM-01', 'TRX-AM-01', 'BCA', '807771234567890', '2026-05-18 16:00:00+07', '2026-05-18 15:35:00+07'),
('PAY-JD-01', 'TRX-JD-01', 'Mandiri', '899990987654321', '2026-05-18 16:30:00+07', NULL);

-- 4. Create View for Reporting
CREATE OR REPLACE VIEW vw_transaction_report AS
SELECT 
    t.id AS transaction_id,
    u.full_name AS buyer_name,
    u.id AS buyer_acronym,
    e.name AS event_name,
    tt.name AS ticket_category,
    t.quantity,
    t.total_amount,
    t.status AS transaction_status,
    p.bank_name,
    p.virtual_account_number,
    p.paid_at,
    t.created_at AS transaction_date
FROM 
    transactions t
JOIN 
    users u ON t.user_id = u.id
JOIN 
    ticket_types tt ON t.ticket_type_id = tt.id
JOIN 
    events e ON tt.event_id = e.id
LEFT JOIN 
    payments p ON t.id = p.transaction_id;

-- ==========================================
-- CRUD OPERATIONS EXAMPLES
-- ==========================================

-- CREATE
INSERT INTO users (id, full_name, email, password_hash, role) 
VALUES ('TS', 'Taylor Smith', 'taylor@example.com', 'secure_hash_098', 'USER');

INSERT INTO transactions (id, user_id, ticket_type_id, quantity, total_amount, status) 
VALUES ('TRX-TS-01', 'TS', 'MOTS-FES', 2, 7000000.00, 'PENDING');

-- READ
-- Checking Stock with Row-Level Locking
BEGIN;
SELECT stock 
FROM ticket_types 
WHERE id = 'MOTS-FES' 
FOR UPDATE;
COMMIT;

-- Viewing a User's Purchase History
SELECT 
    t.id AS transaction_id, 
    e.name AS event, 
    tt.name AS category, 
    t.quantity, 
    t.total_amount, 
    t.status 
FROM transactions t
JOIN ticket_types tt ON t.ticket_type_id = tt.id
JOIN events e ON tt.event_id = e.id
WHERE t.user_id = 'AM'
ORDER BY t.created_at DESC;

-- Using the Reporting View
SELECT * FROM vw_transaction_report 
WHERE transaction_status = 'PAID' 
AND event_name LIKE '%Coldplay%';

-- UPDATE
-- Decrementing Stock After a Reservation
UPDATE ticket_types 
SET stock = stock - 2 
WHERE id = 'MOTS-FES';

-- Confirming Payment (Webhook from Bank)
BEGIN;
UPDATE transactions 
SET status = 'PAID', updated_at = CURRENT_TIMESTAMP 
WHERE id = 'TRX-JD-01' AND status = 'PENDING';

UPDATE payments 
SET paid_at = CURRENT_TIMESTAMP 
WHERE transaction_id = 'TRX-JD-01';
COMMIT;

-- DELETE
-- Hard Deleting an Expired Transaction
DELETE FROM transactions 
WHERE status = 'EXPIRED' 
AND created_at < CURRENT_TIMESTAMP - INTERVAL '1 day';

-- Restoring Stock for a Failed Transaction
BEGIN;
UPDATE ticket_types 
SET stock = stock + (SELECT quantity FROM transactions WHERE id = 'TRX-JD-01')
WHERE id = (SELECT ticket_type_id FROM transactions WHERE id = 'TRX-JD-01');

UPDATE transactions 
SET status = 'EXPIRED', updated_at = CURRENT_TIMESTAMP 
WHERE id = 'TRX-JD-01';
COMMIT;
